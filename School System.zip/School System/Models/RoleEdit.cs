﻿using Microsoft.AspNetCore.Identity;
using School_System.Models;

namespace School_System.Models {
    public class RoleEdit {
        public IdentityRole Role { get; set; }
        public IEnumerable<AppUser> Members { get; set; }
        public IEnumerable<AppUser> NonMembers { get; set; }
    }
}
