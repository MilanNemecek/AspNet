﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using School_System.Models;
using School_System.ViewModels;

namespace School_System.Services
{
    public class GradeService
    {
        ApplicationDBContext dbContext;
        public GradeService(ApplicationDBContext context)
        {
            this.dbContext = context;
        }
        public async Task<IEnumerable<Grade>> GetAllAsync()
        {
            //return await dbContext.Grades.
                //Include(st=>st.Student).Include(sub=>sub.Subject).ToListAsync();
                var grades = await dbContext.Grades.Include(st =>
                st.Student).Include(sub => sub.Subject).ToListAsync();
            return grades;
        }
        public async Task<GradesDropdownsViewModel> GetGradesDropdownsValues()
        {
            var gradesDropdownsData = new GradesDropdownsViewModel()
            {
                Students = await dbContext.Students.ToListAsync(),
                Subjects = await dbContext.Subjects.ToListAsync(),
            };
            return gradesDropdownsData;
        }

        internal async Task CreateAsync(GradesViewModel newGrade)
        {
            var gradeToInsert = new Grade()
            {
                Student = await dbContext.Students.FirstOrDefaultAsync(st => 
                st.Id == newGrade.StudentId),
                Subject = await dbContext.Subjects.FirstOrDefaultAsync(sub => 
                sub.Id == newGrade.SubjectId),
                Mark = newGrade.Mark,
                Topic = newGrade.Topic,
                Date = DateTime.Today
            };
            if (gradeToInsert.Subject != null && gradeToInsert.Student != null)
            {
                await dbContext.Grades.AddAsync(gradeToInsert);
                await dbContext.SaveChangesAsync();
            }
        }
        public async Task<Grade> GetByIdAsync(int id)
        {
            return await
                dbContext.Grades.Include(st=>st.Student).
                Include(sub =>sub.Subject).FirstOrDefaultAsync(g => g.Id == id);
        }

        internal async Task UpdateAsync(int id, GradesViewModel updatedGrade)
        {
            var dbGrade = await dbContext.Grades.FirstOrDefaultAsync(gr=>
            gr.Id==id);
            if (dbGrade != null)
            {
                dbGrade.Student = dbContext.Students.FirstOrDefault(st=>
                st.Id == updatedGrade.StudentId);
                dbGrade.Subject = dbContext.Subjects.FirstOrDefault(sub =>
                sub.Id == updatedGrade.SubjectId);
                dbGrade.Topic = updatedGrade.Topic;
                dbGrade.Mark = updatedGrade.Mark;
                dbGrade.Date = updatedGrade.Date;
            }
            dbContext.Update(dbGrade);
            await dbContext.SaveChangesAsync();
        }
        internal async Task DeleteAsync(int id)
        {
            var gradeToDelete = await dbContext.Grades.FirstOrDefaultAsync
                (g => g.Id==id); 
            dbContext.Grades.Remove(gradeToDelete);
            await dbContext.SaveChangesAsync();
        }
        
    }
}





















