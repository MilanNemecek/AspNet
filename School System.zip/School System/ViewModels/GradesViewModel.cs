﻿using System.ComponentModel;

namespace School_System.ViewModels
{ 
        public class GradesViewModel
        {
            public int Id { get; set; }
            [DisplayName("Student Name")]
            public int StudentId { get; set; }
            [DisplayName("Subject")]
            public int SubjectId { get; set; }
            public string Topic { get; set; }
            [DisplayName("Grade")]
            public int Mark { get; set; }
            public DateTime Date { get; set; }
        }
    
}
